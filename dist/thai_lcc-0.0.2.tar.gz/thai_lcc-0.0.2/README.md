# Large Thai Character Clusters (LTCCs)
Large Thai Character Clusters (LTCCs) is an extension of Thai Character Clusters (TCCs) by Theeramunkong et al. 2000.
https://dl.acm.org/doi/pdf/10.1145/355214.355225
The purpose of this extension is to segment the largest unambiguous TCC possible.